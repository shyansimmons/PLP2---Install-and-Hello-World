#include <iostream> /* need to have this here to run program (configuration)
Hello world program first assignment
*/

using namespace std; /* (optional line telling compiler that we are using namespace std;
namespace is where you can have functions with similar names,
std related to console input and output)
*/

int main() //program begins here executes first
{
    cout << "Hello world!" << endl; //
    return 0;
}


